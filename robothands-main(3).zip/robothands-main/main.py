"""
Starts `task/robot.py` and `task/hands.py` on separate threads.
"""

from queue import Queue
from threading import Thread
from task import hands, robot
import sys

USE_LOCALHOST = "--localhost" in sys.argv
queue1, queue2 = Queue(maxsize=1), Queue(maxsize=1)

threads = (
    Thread(
        target=robot.run,
        name="Robot Task",
        args=(queue1, queue2, USE_LOCALHOST),
        daemon=True,
    ),
    Thread(target=hands.run, name="Hands Task", args=(queue2, queue1), daemon=True),
)

[t.start() for t in threads]
[t.join() for t in threads]
