from enum import Enum
from queue import Empty, Full, Queue
from typing import Any, List, Sequence, Tuple, Union
from my_packages.hands.features import Features


class PeerThreadException(Exception):
    """
    Exception raised when a thread that this thread depends on failed for
    whatever reason.
    """

    def __init__(self) -> None:
        super().__init__("Peer thread commanded this thread to abort")


def get_features_as_payload(features: Features) -> "FeaturesPayload":
    return FeaturesPayload(
        normal=features.normal.value.tolist(),
        center=features.center.position.value.tolist(),
    )


class FeaturesPayload:
    """
    Same as Features, but with non-essencial information and methods removed.
    """

    normal: Tuple[float, float, float]
    center: Tuple[float, float, float]

    def __init__(self, normal: Sequence[float], center: Sequence[float]) -> None:
        if len(normal) != 3:
            raise ValueError(
                f"Expected normal array to contain 3 floats (x,y,z). Got: {normal}"
            )
        if len(center) != 3:
            raise ValueError(
                f"Expected center array to contain 3 floats (x,y,z). Got: {center}"
            )
        self.normal = normal[0], normal[1], normal[2]
        self.center = center[0], center[1], center[2]


class Signal(Enum):
    ABORT = 0
    PAUSE = 1
    CONTINUE = 2
    CHANGE_ORIGIN = 3
    CLEAR_ALARM = 4


def poll(queue: Queue) -> Union[Signal, FeaturesPayload, None]:
    """
    Polls the given queue to check if it has any items. If it does, return the
    item imediately. If it does not, return `None`.
    """
    try:
        return queue.get_nowait()
    except Empty:
        return None


def try_send(queue: Queue, item: Any):
    """
    Tries to send an item to the queue. If the queue is full, does not send
    item, but also doesn't raise any exceptions (item is discarded).

    Returns a boolean representing whether the item was sent or not
    """
    try:
        queue.put_nowait(item)
        return True
    except Full:
        return False


def send(queue: Queue, item: Any):
    """
    Sends item to the queue whenever possible. Will block execution until a free
    slot in the queue is opened.
    """
    queue.put(item)
