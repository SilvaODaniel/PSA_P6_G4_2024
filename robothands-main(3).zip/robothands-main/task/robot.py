from queue import Queue
from time import sleep, perf_counter as now
from typing import Optional, Union
from my_packages.robot.interface import EC66Robot, ETController
from my_packages.robot.transform import CoordinatesTransformer
from .common import (
    FeaturesPayload,
    PeerThreadException,
    poll,
    try_send,
    Signal,
)

IP = "192.168.2.66"
PORT = 8055

# Transmission parameters
LOOKAHEAD = 800  # 200
T = 20  # 20
SECONDS_PER_LOOP = T / 5000  # 1000
SMOOTHNESS = 1  # 0.1


class Parameters:
    def __init__(self) -> None:
        self.paused = True
        self.transformer: Optional[CoordinatesTransformer] = None
        self.arrived = False


def handle_incoming_data(
    robot: EC66Robot, data: Union[Signal, FeaturesPayload, None], params: Parameters
):
    if isinstance(data, Signal):
        handle_incoming_signal(robot, data, params)

    elif isinstance(data, FeaturesPayload) and not params.paused:
        handle_incoming_features(robot, data, params)


def handle_incoming_features(
    robot: EC66Robot, payload: FeaturesPayload, params: Parameters
):
    x, y, z = payload.center
    rx, ry, rz = payload.normal
    payload = FeaturesPayload(center=(x, z, y), normal=(rx, ry, rz))
    if params.transformer is None:
        pose = None
        while pose is None:
            pose = robot.get_position()
            if pose is None:
                print("Failed to retrieve pose, retrying...")
            sleep(0.5)
        params.transformer = CoordinatesTransformer()
        params.transformer.add_position_factor(1000)
        params.transformer.adjust_xyz_offsets_to_pose(pose, payload)
    else:
        pose = params.transformer.apply(payload)
        robot.set_target(pose, interpolate="joint_angles")


def handle_incoming_signal(robot: EC66Robot, signal: Signal, params: Parameters):
    if signal is Signal.ABORT:
        raise PeerThreadException()
    elif signal is Signal.PAUSE:
        params.paused = True
    elif signal is Signal.CONTINUE:
        params.paused = False
    elif signal is Signal.CHANGE_ORIGIN:
        params.transformer = None
    elif signal is Signal.CLEAR_ALARM:
        robot.clear_alarm()
        if robot.get_transparent_transmission_state() == 0:
            robot.init_transparent_transmission(
                lookahead=LOOKAHEAD, t=T, smoothness=SMOOTHNESS
            )
    else:
        raise Exception(f"Unknown signal {signal}")


def loop(robot: EC66Robot, params: Parameters, read_queue: Queue):
    payload = poll(queue=read_queue)
    handle_incoming_data(robot, payload, params)

    if params.paused:
        return

    _, arrived = robot.move_to_target()
    if arrived and not params.arrived:
        print("Arrived to target")
    params.arrived = arrived


def run(read_queue: Queue, write_queue: Queue, localhost: bool):
    params = Parameters()
    ip = "localhost" if localhost else IP

    try:
        with ETController(ip=ip, port=PORT, log_responses=True) as robot:
            robot.init_transparent_transmission(
                lookahead=LOOKAHEAD, t=T, smoothness=SMOOTHNESS
            )

            while True:
                start = now()
                loop(robot, params, read_queue)
                loop_time_remaining = SECONDS_PER_LOOP - (now() - start)
                if loop_time_remaining > 0:
                    sleep(loop_time_remaining)

    except PeerThreadException as e:
        print(e)
    except BaseException as e:
        try_send(queue=write_queue, item=Signal.ABORT)
        raise
