from queue import Queue
from time import perf_counter as now
from typing import Dict, Literal, Optional
from my_packages.hands.detector import HandsDetector
from my_packages.hands_demo.show import (
    show_detections,
    show_fps,
    show_instructions,
    show_paused,
    show_play,
)
from my_packages.image.video_session import VideoSession
from .common import (
    PeerThreadException,
    Signal,
    get_features_as_payload,
    poll,
    send,
    try_send,
)

Command = Literal["Continue", "Reset Origin", "Pause", "Clear Alarm", "Exit"]
# Change this to fit your needs. Instructions and such are also updated
PAUSED_KEYBINDS: Dict[str, Command] = {
    "q": "Exit",
    "c": "Continue",
    "r": "Reset Origin",
    "a": "Clear Alarm",
}
UNPAUSED_KEYBINDS: Dict[str, Command] = {"q": "Exit", "p": "Pause", "a": "Clear Alarm"}

COMMAND_SIGNAL_BINDS: Dict[Command, Signal] = {
    "Continue": Signal.CONTINUE,
    "Pause": Signal.PAUSE,
    "Reset Origin": Signal.CHANGE_ORIGIN,
    "Clear Alarm": Signal.CLEAR_ALARM,
}

# Whether to flip the image horizontally or not (did not test `False`, may be
# buggy)
MIRROR_IMAGE = True

# Image resolution. Affects model performance (overall higher is better but may
# be slower)
WIDTH = 1920
HEIGHT = 1080

# Whether to display FPS in the corner of the video session window
SHOW_FPS = True
# Display Instructions in the video session window (Press KEY to ACTION)
SHOW_INSTRUCTIONS = True

# Time interval between sending messages. May be set to 0 to not wait at all
# (not recommended). The higher this time the more performance (higher FPS), but
# lower responsiveness on the consumer side (robot)
SEND_EVERY_S = 0.2
# Same as above, but for receiving messages
POLL_EVERY_S = 1


def handle_keypress(write_queue, paused, pressed_key) -> Optional[bool]:
    keybinds = PAUSED_KEYBINDS if paused else UNPAUSED_KEYBINDS
    command = keybinds.get(pressed_key, None)

    if command is None:
        return

    signal = COMMAND_SIGNAL_BINDS.get(command, None)

    if signal is None:
        return

    if signal is not Signal.PAUSE and signal is not Signal.CONTINUE:
        send(write_queue, signal)
        return

    if signal is Signal.PAUSE and not paused:
        send(write_queue, signal)
        return True

    if signal is Signal.CONTINUE and paused:
        send(write_queue, signal)
        return False

    return paused


def run(read_queue: Queue, write_queue: Queue):
    paused = True
    try:
        # Used to avoid polling/sending messages every single loop
        last_sent = now()
        last_polled = now()

        session = VideoSession(
            stop_key=next(
                key for key, value in UNPAUSED_KEYBINDS.items() if value == "Exit"
            ),
            flip_horizontal=MIRROR_IMAGE,
        )
        session.set_width(WIDTH)
        session.set_height(HEIGHT)

        detector = HandsDetector(
            min_detection_confidence=0.6,
            min_tracking_confidence=0.5,
            sliding_window_size=10,
            img_is_mirrored=MIRROR_IMAGE,
            target_hand="Right",
        )

        # Start main loop. Every iteration of the loop will correspond to a frame in
        # the video feed.
        for image, window, pressed_key in session:
            if pressed_key is not None:
                next_pause_state = handle_keypress(write_queue, paused, pressed_key)
                if next_pause_state is not None:
                    paused = next_pause_state

            # Read incoming messages every POLL_EVERY_S
            incoming_payload = None
            if now() - last_polled > POLL_EVERY_S:
                incoming_payload = poll(queue=read_queue)
                last_polled = now()

            if incoming_payload is Signal.ABORT:
                raise PeerThreadException()

            results = detector.detect(image)

            # Something was detected in the image
            if results is not None:
                # Enough time has passed and we may send another target point to
                # the queue
                if now() - last_sent > SEND_EVERY_S:
                    payload = get_features_as_payload(results)
                    sent = try_send(queue=write_queue, item=payload)
                    if sent:
                        last_sent = now()

                # Display detections in the image
                show_detections(window, results)

            # Display frames per second in the image
            if SHOW_FPS:
                show_fps(window)

            if SHOW_INSTRUCTIONS:
                if paused:
                    show_instructions(window, PAUSED_KEYBINDS)
                else:
                    show_instructions(window, UNPAUSED_KEYBINDS)
            if paused:
                show_paused(window)
            else:
                show_play(window)

            window.show()
    except PeerThreadException as e:
        print(e)
    except BaseException:
        send(queue=write_queue, item=Signal.ABORT)
        raise

    send(queue=write_queue, item=Signal.ABORT)
