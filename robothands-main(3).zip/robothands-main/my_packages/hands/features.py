from dataclasses import dataclass
from typing import Literal, Optional, Tuple
from my_packages.geometry3d.shape import Point, Triangle
from my_packages.geometry3d.vector import Vector3D
from .consts import HandPoint
from .detection_data import DetectionData


@dataclass
class Features:
    """
    Class that contains all the valuable info we need regarding hand detection.
    """

    normal: Vector3D
    """
    The vector normal of the hand's palm. The vector is normalized.
    """
    center: Point
    """
    Returns a best guess of the (x, y, z) of the palm's center point in the
    frame of reference of the camera.
    """
    original_data: DetectionData
    """
    The results from which these features were obtained from
    """

    @staticmethod
    def _get_palm_landmark_indices(
        hand_side: Literal["Left", "Right"], image_is_mirrored: bool
    ) -> Tuple[HandPoint, HandPoint, HandPoint]:
        is_right_side = (hand_side == "Right" and not image_is_mirrored) or (
            hand_side == "Left" and image_is_mirrored
        )

        indices = (
            (HandPoint.WRIST, HandPoint.INDEX_KUCKLE, HandPoint.PINKY_KUCKLE)
            if is_right_side
            else (HandPoint.WRIST, HandPoint.PINKY_KUCKLE, HandPoint.INDEX_KUCKLE)
        )

        return indices

    @staticmethod
    def get_feature_from_raw_results(
        data: DetectionData,
        target_hand: Optional[Literal["Right", "Left"]],
        image_is_mirrored: bool,
    ) -> Optional["Features"]:
        """
        Extrapolates features from the given `data`.

        Returns None if `target_hand` is given and is not the hand that was
        detected in `data`
        """
        if target_hand is not None and data.side != target_hand:
            return None

        indices = Features._get_palm_landmark_indices(data.side, image_is_mirrored)
        p1, p2, p3 = (data.get_pos(hand_point, "Wrist") for hand_point in indices)
        normal = Triangle(p1, p2, p3).normal(normalized=True)
        center = Point.average_of(
            *(data.get_pos(hand_point, "Camera") for hand_point in indices)
        )

        features = Features(
            normal=normal,
            center=center,
            original_data=data,
        )

        return features

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(normal={self.normal}, center={self.center})"
