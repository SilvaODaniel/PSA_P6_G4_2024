from typing import Collection, List, Optional
from numpy.typing import NDArray
import numpy as np


class MovingAverage:
    """
    Applies a moving average to one `float` value at a time depending on its
    `window_size`. Note that using this class with a window size of `1` is
    effectively the same as not using a filter at all. Note that the first view
    values are already valid and the moving average will shrink the window size
    to fit the first few values

    ## Example
    ```python
    ma = MovingAverage(4)
    assert ma.apply(0) == 0.0
    assert ma.apply(1) == 0.5
    assert ma.apply(2) == 1.0
    assert ma.apply(3) == 1.5
    assert ma.apply(4) == 2.5
    ```
    """

    def __init__(self, window_size: int) -> None:
        if window_size < 1:
            raise ValueError("window_size should be 1 or higher")
        self._wsize = window_size

        self._window: List[Optional[float]] = [None] * window_size

    def apply(self, value: float) -> float:
        self._window.pop(0)
        self._window.append(value)
        null_filtered_list = [i for i in self._window if i is not None]
        average = sum(null_filtered_list) / len(null_filtered_list)
        return average


class ArrayMovingAverage:
    """
    See `MovingAverage` class. This class does the same but for different groups
    of `float`s. This does NOT apply the same filter to all the elements of the
    given array but rather keeps a separate buffer for each element, such that
    the same array shape is always expected.

    This is effectively the same as keeping different instances of
    `MovingAverage` and applying them separately for each element in the array

    ## Example
    ```python
    filter4d = ArrayMovingAverage(window_size=2, array_size=2)
    assert np.all((filter4d.apply([1, 2]), np.array([1, 2])))
    assert np.all((filter4d.apply([2, 4, 6, 8]), np.array([1.5, 3])))
    assert np.all((filter4d.apply([2, 4]), np.array([2, 4])))
    ```
    """

    def __init__(self, window_size: int, array_size: int) -> None:
        if window_size < 1:
            raise ValueError("window_size should be 1 or higher")

        self._filter_array = [MovingAverage(window_size) for _ in range(array_size)]

    def apply(self, value: Collection[float]) -> NDArray[np.float64]:
        out = np.array([f.apply(v) for f, v in zip(self._filter_array, value)])

        return out
