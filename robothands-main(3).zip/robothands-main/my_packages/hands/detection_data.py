from typing import List, Literal, Optional

from my_packages.geometry3d.shape import Point
from my_packages.geometry3d.vector import Vector3D
from .consts import HandPoint
from .mediapipe_wrappers import Landmark, MediaPipeResult
import pickle
import numpy as np
from numpy.typing import NDArray

CoordinatesFrame = Literal["Wrist", "Camera", "Image"]


def get_numpy_matrix_from_landmarks(
    landmarks: List[Landmark],
) -> NDArray[np.float64]:
    landmark_count = len(landmarks)
    if landmark_count != 21:
        raise ValueError(
            f"Expected landmarks list to have 21 points, found {landmark_count}"
        )
    landmarks_matrix = np.zeros((21, 3), dtype=np.float64)
    for index, landmark in enumerate(landmarks):
        landmarks_matrix[index] = (landmark.x, landmark.y, landmark.z)

    return landmarks_matrix


def get_points_from_ndarray(ndarray: NDArray[np.float64]) -> List[Point]:
    return [Point(Vector3D(position_array)) for position_array in ndarray]


class DetectionData:
    """
    This is a wrapper class of the raw detection data provided by mediapipe's
    hand detection model, which helps streamline access to its information and
    also narrows down detections obtained from mediapipe's result to the best
    detection.
    """

    side: Literal["Left", "Right"]
    confidence: float
    landmarks_matrix: NDArray[np.float64]
    world_landmarks_matrix: NDArray[np.float64]
    camera_landmarks_matrix: Optional[NDArray[np.float64]]

    def __init__(
        self,
        side: Literal["Left", "Right"],
        confidence: float,
        landmarks_matrix: NDArray[np.float64],
        world_landmarks_matrix: NDArray[np.float64],
    ) -> None:
        self.side = side
        self.confidence = confidence
        self.landmarks_matrix = landmarks_matrix
        self.world_landmarks_matrix = world_landmarks_matrix
        self.camera_landmarks_matrix = None

    @staticmethod
    def from_mediapipe_result(result: MediaPipeResult) -> Optional["DetectionData"]:
        """
        Given the raw result obtained from the hand detection model, attempt to
        create an isntance of `DetectionData`. If no hands were detected this
        method returns `None`.
        """
        if (
            result.multi_hand_landmarks is None
            or result.multi_handedness is None
            or result.multi_hand_world_landmarks is None
        ):
            return

        all_landmarks = result.multi_hand_landmarks
        all_world_landmarks = result.multi_hand_world_landmarks
        all_hand_classifications = result.multi_handedness

        best_hand = None
        best_index = None

        for index, hand_classification in enumerate(all_hand_classifications):
            hand = hand_classification.classification[0]
            if best_hand is None or hand.score > best_hand.score:
                best_hand = hand
                best_index = index

        if best_hand is None or best_index is None:
            return

        landmarks_matrix = get_numpy_matrix_from_landmarks(
            all_landmarks[best_index].landmark
        )
        world_landmarks_matrix = get_numpy_matrix_from_landmarks(
            all_world_landmarks[best_index].landmark
        )

        return DetectionData(
            side=best_hand.label,
            confidence=best_hand.score,
            landmarks_matrix=landmarks_matrix,
            world_landmarks_matrix=world_landmarks_matrix,
        )

    def get_pos(self, reference: HandPoint, coord_frame_ref: CoordinatesFrame) -> Point:
        """
        Returns a `Point` which contains the position of the given
        `coord_frame_ref`.

        `coord_frame_ref` can be one of:

        - `Wrist`: provides real 3D coordinates with the origin at the wrist;

        - `Camera`: provides real 3D coordinates with the origin at the camera;

        - `Image`: provides `x` and `y` as normalized values between 0 and 1
        representing the position in the 2D frame (resolution agnostic). `z`
        represents an estimate of how far the point is (smaller means closer to
        the camera) with the origin at the wrist.

        Regardless of the frame of reference, the result is always returned as a
        3D `Point`.
        """
        if coord_frame_ref == "Image":
            ref_matrix = self.landmarks_matrix
        elif coord_frame_ref == "Camera":
            ref_matrix = self.camera_landmarks_matrix
            if ref_matrix is None:
                raise ValueError(
                    "Could not get hand point position from coord_frame_ref 'Camera' because this DetectionData instance hasn't yet been converted to use the coordinate system from PnP."
                )
        elif coord_frame_ref == "Wrist":
            ref_matrix = self.world_landmarks_matrix
        else:
            raise ValueError(
                f"Unknown coordinates frame of reference: '{coord_frame_ref}'"
            )
        return Point(Vector3D(ref_matrix[reference.value]))

    def set_camera_landmarks(self, coordinates_matrix: NDArray[np.float64]):
        self.camera_landmarks_matrix = coordinates_matrix

    def save(self, file_name: str):
        """
        Saves current instance to provided file path. File will be created if it
        does not exist, but its containing folder must exist.

        Can recreate this `DetectionData` later on instance using
        `DetectionData.load(file_name)`
        """
        with open(file_name, "wb") as f:
            pickle.dump(self, f)

    @staticmethod
    def load(file_name: str) -> "DetectionData":
        """
        Recreates `DetectionData` from provided file path. Useful if you want to
        have samples to analyze separately and don't want to run the entire
        detection model + camera over and over again
        """
        with open(file_name, "rb") as f:
            return pickle.load(f)
