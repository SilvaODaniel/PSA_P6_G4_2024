"""
Mostly stubs (i.e. classes without any behavior, and which never even get
instantiated) for type hinting, because mediapipe's types are not given by
Google's package. This is useless if you don't use Python type checkers.

These types were manually adapted from:
    
    https://mediapipe.readthedocs.io/en/latest/solutions/hands.html

"""

from typing import List, Literal, Optional
import mediapipe as mp
from numpy.typing import NDArray
import numpy as np
from my_packages.utils.decorator import stub


@stub
class Landmark:
    """Fields taken from sample detections."""

    presence: float
    visibility: float
    x: float
    """
    If coming from `multi_hand_landmarks` this is the X position in the frame
    where this Landmark is located, normalized in the interval [0,1] (e.g. 0.5
    in an image with 800x600 would mean this is the 400th horizontal pixel)
    
    If coming from `multi_hand_world_landmarks` this is measured in a real 3D
    coordinate system with the origin point at the hand's average point
    (geometric center)
    """
    y: float
    """
    If coming from `multi_hand_landmarks` this is the Y position in the frame
    where this Landmark is located, normalized in the interval [0,1] (e.g. 0.5
    in an image with 800x600 would mean this is the 300th vertical pixel)
    
    If coming from `multi_hand_world_landmarks` this is measured in a real 3D
    coordinate system with the origin point at the hand's average point
    (geometric center)
    """
    z: float
    """
    If coming from `multi_hand_landmarks` represents the landmark depth with the
    depth at the wrist being the origin, and the smaller the value the closer
    the landmark is to the camera. The magnitude of z uses roughly the same
    scale as x.
    
    If coming from `multi_hand_world_landmarks` this is measured in a real 3D
    coordinate system with the origin point at the hand's average point
    (geometric center)
    """


@stub
class LandmarkContainer:
    """Fields taken from sample detections."""

    landmark: List[Landmark]


@stub
class HandClassification:
    """Fields taken from sample detections."""

    label: Literal["Left", "Right"]
    score: float


@stub
class HandClassContainer:
    """Fields taken from sample detections."""

    classification: List[HandClassification]


@stub
class MediaPipeResult:
    multi_hand_landmarks: Optional[List[LandmarkContainer]]
    """List of landmarks using frame pixels as coordinates"""
    multi_hand_world_landmarks: Optional[List[LandmarkContainer]]
    """List of landmarks using estimated real world measurements as coordinates"""
    multi_handedness: Optional[List[HandClassContainer]]
    """List of classifications for each hand, in regards to the likelihood that
    the hand is a left hand or right hand"""


@stub
class HandsModel:
    def process(self, frame: NDArray[np.float64]) -> MediaPipeResult: ...


@stub
class HandsModelInitializer:
    def Hands(
        self,
        static_image_mode: bool = False,
        model_complexity: Literal[0, 1] = 1,
        max_num_hands: int = 2,
        min_detection_confidence: float = 0.5,
        min_tracking_confidence: float = 0.5,
    ) -> HandsModel: ...


def get_model_initializer() -> HandsModelInitializer:
    mp_hands: HandsModelInitializer = mp.solutions.hands  # type: ignore
    return mp_hands
