from enum import Enum


class HandPoint(Enum):
    WRIST = 0
    THUMB_KUCKLE = 1
    THUMB_JOINT_2 = 2
    THUMB_JOIN_3 = 3
    THUMB_TIP = 4
    INDEX_KUCKLE = 5
    INDEX_JOINT_2 = 6
    INDEX_JOIN_3 = 7
    INDEX_TIP = 8
    MIDDLE_KUCKLE = 9
    MIDDLE_JOINT_2 = 10
    MIDDLE_JOIN_3 = 11
    MIDDLE_TIP = 12
    RING_KUCKLE = 13
    RING_JOINT_2 = 14
    RING_JOIN_3 = 15
    RING_TIP = 16
    PINKY_KUCKLE = 17
    PINKY_JOINT_2 = 18
    PINKY_JOIN_3 = 19
    PINKY_TIP = 20
