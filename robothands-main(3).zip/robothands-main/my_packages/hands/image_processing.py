import cv2
from .detection_data import DetectionData
import numpy as np
from numpy.typing import NDArray


class Image3DConverter:
    """
    Given any sample frame, produces an instance which is able to map any points
    into 3D space. The frame used in instantiation is only used for gathering
    resolution data, it does not need to contain any hand detections.
    """

    def __init__(
        self,
        sample_frame: NDArray[np.float64],
    ) -> None:
        height, width, _ = sample_frame.shape
        center_x, center_y = width / 2, height / 2
        self._camera_matrix = np.array(
            [[width, 0, center_x], [0, width, center_y], [0, 0, 1]],
            dtype="double",
        )
        self._height = float(height)
        self._width = float(width)

    def _transformation_matrix(
        self, image_data: NDArray[np.float64], model_data: NDArray[np.float64]
    ):
        image_points = np.array(
            [[i[0] * self._width, i[1] * self._height] for i in image_data],
            dtype=np.float64,
        )
        model_points = model_data.copy()

        success, _, translation_vector = cv2.solvePnP(
            model_points,
            image_points,
            self._camera_matrix,
            np.zeros((4, 1), dtype=np.float64),
            flags=cv2.SOLVEPNP_SQPNP,
        )

        if not success:
            raise RuntimeError("Failed to convert 2D sampled points into 3D space")

        transformation_matrix = np.eye(4)
        transformation_matrix[0:3, 3] = translation_vector.squeeze()
        return transformation_matrix

    def convert(self, data: DetectionData) -> NDArray[np.float64]:
        """
        Given `data`, returns an array representing all landmarks' coordinates
        using the camera as a frame of reference. Result is in the same unit as
        the world landmarks' coordinates (meters).
        """
        world_landmarks = data.world_landmarks_matrix
        image_landmarks = data.landmarks_matrix

        landmarks_homogeneous = np.concatenate(
            (world_landmarks, np.ones((21, 1))), axis=1
        )

        transf_matrix = self._transformation_matrix(image_landmarks, world_landmarks)

        return landmarks_homogeneous.dot(np.linalg.inv(transf_matrix).T)[:, 0:-1]
