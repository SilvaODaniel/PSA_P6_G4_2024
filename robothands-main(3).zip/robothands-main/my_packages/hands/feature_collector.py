from dataclasses import dataclass
from typing import Literal, Optional
from my_packages.geometry3d.shape import Point
from my_packages.geometry3d.vector import Vector3D
from .filters import ArrayMovingAverage, MovingAverage
from .features import Features
from .detection_data import DetectionData


@dataclass
class _FilterCluster:
    """
    Organizes many filters into one class. This is just so that we don't have to
    check for the presence of each fitler individually and can simply check if
    the cluster itself is valid
    """

    normal: ArrayMovingAverage
    center: ArrayMovingAverage


class FeatureCollector:
    """
    Class that helps filtering the `Features` obtained from raw detection data
    provided by mediapipe hand detection model.

    The feature extraction logic itself is contained in the `Features` class.
    """

    _features: Optional[Features]
    _target_hand: Optional[Literal["Right", "Left"]]
    _filters: Optional[_FilterCluster]
    _img_is_mirrored: bool

    def __init__(
        self,
        window_size: Optional[int],
        img_is_mirrored: bool,
        target_hand: Optional[Literal["Left", "Right"]],
    ) -> None:
        self._filters = None
        if window_size is not None:
            self._filters = _FilterCluster(
                normal=ArrayMovingAverage(window_size, 3),
                center=ArrayMovingAverage(window_size, 3),
            )
        self._target_hand = target_hand
        self._features = None
        self._img_is_mirrored = img_is_mirrored

    def update(self, data: DetectionData) -> Optional[Features]:
        """
        Updates this feature collector's filters and feature and returns the
        updated feature. This method will only yield `None` if no features were
        detected throughout its entire lifetime. If no features were detected
        but a previous set of features exists, that will be returned instead
        """
        features = Features.get_feature_from_raw_results(
            data, self._target_hand, self._img_is_mirrored
        )
        if features is None:
            return self._features
        return self._filter_features(features)

    def _filter_features(self, features: Features) -> Features:
        filters = self._filters
        if filters:
            new_normal_array = filters.normal.apply(features.normal.value)
            new_center_array = filters.center.apply(features.center.position.value)
        else:
            new_normal_array = features.normal.value
            new_center_array = features.center.position.value

        features.center = Point(Vector3D(new_center_array))
        features.normal = Vector3D(new_normal_array)

        self._features = features

        return self._features
