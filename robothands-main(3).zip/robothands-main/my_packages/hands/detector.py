from typing import Literal, Optional
import numpy as np
from .detection_data import DetectionData
from .feature_collector import FeatureCollector
from .mediapipe_wrappers import get_model_initializer
from .image_processing import Image3DConverter


class HandsDetector:
    """
    Manages the hand detection model, filters and feature collection.
    """

    def __init__(
        self,
        img_is_mirrored: bool,
        min_detection_confidence: float = 0.5,
        min_tracking_confidence: float = 0.5,
        sliding_window_size: Optional[int] = None,
        target_hand: Optional[Literal["Right", "Left"]] = None,
    ) -> None:
        """
        - `img_is_mirrored` (`bool`): Whether the frames that will be fed to
        this instance are mirrored horizontally or not.

        - `min_detection_confidence` (`float`, optional): Value between 0 and 1.
        The higher this value, the more resistant the model will be to find new
        hands other than the one it has already detected. You should have this
        value in lower amounts if you expect to detect many different hands that
        appear and disappear on the screen. Defaults to 0.5.

        - `min_tracking_confidence` (`float`, optional): Value between 0 and 1.
        The higher this value, the more resistant the model will be track hands
        it has already detected, forcing the detection part of the model to do
        most of the heavy lifting. You should have this value in lower amounts
        if you expect the same hand to be on the screen at all times. Defaults
        to 0.5.

        - `feature_filter` (`Filter`, optional): A filter to be applied to all
        features. The same filter is applied equally accross the board, there is
        no way to apply different filters to different features. Defaults to
        None.

        - `target_hand` (`"Right" | "Left" | None`, optional): If not `None`
        will ignore hand detections from hands other than the provided hand
        side, otherwise detects any hand, regardless of handedness. Defaults to
        `None`.
        """
        self._model = get_model_initializer().Hands(
            max_num_hands=1,
            min_detection_confidence=min_detection_confidence,
            min_tracking_confidence=min_tracking_confidence,
        )
        self._img_is_mirrored = img_is_mirrored
        self._wsize = sliding_window_size
        self._target_hand: Optional[Literal["Right", "Left"]] = target_hand
        self._feature_collector = FeatureCollector(
            window_size=self._wsize,
            img_is_mirrored=self._img_is_mirrored,
            target_hand=self._target_hand,
        )
        self._converter: Optional[Image3DConverter] = None

    def detect(self, frame: np.ndarray):
        """
        Processes a single frame and returns its features. If this instance
        hasn't been calibrated, than the raw uncalibrated features will be
        returned. Returns `None` if the model could not find any hand (or target
        hand, if one was provided) in the current frame
        """
        results = DetectionData.from_mediapipe_result(self._model.process(frame))
        features = None

        if results is not None:
            converter = self._get_converter(frame)
            camera_landmarks = converter.convert(results)
            results.set_camera_landmarks(camera_landmarks)
            features = self._feature_collector.update(results)

        return features

    def _get_converter(self, frame: np.ndarray) -> Image3DConverter:
        if self._converter is None:
            self._converter = Image3DConverter(frame)
        return self._converter
