TOLERANCE = 5e-8
"""
For floating point types, this is the absolute threshold for two floats to be
considered 'equal'.
"""

COLLINEARITY_DOT_THRESHOLD = 1 - TOLERANCE
"""
If the dot product between two normalized vectors is higher than this, then the
two vectors are considered to be collinear
"""
