from math import sqrt
from typing import Union
import numpy as np
import numpy.typing as npt
from .consts import COLLINEARITY_DOT_THRESHOLD, TOLERANCE


class Vector3D:
    """
    Wraps a 3 element numpy array to represent a type-safe 3D vector
    """

    def __init__(self, array: npt.NDArray[np.float64]) -> None:
        expected_shape = (3,)
        if array.shape != expected_shape:
            raise ValueError(
                f"Vector3D's constructor expects a numpy array with a column vector of 3 (i.e. shape {expected_shape}) instead got numpy array of shape {array.shape}"
            )
        self._value = array

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({self.x}, {self.y}, {self.z})"

    @staticmethod
    def xyz(x: float, y: float, z: float):
        return Vector3D(np.array((x, y, z)))

    @property
    def value(self):
        return self._value.copy()

    @property
    def x(self) -> float:
        return self._value[0]

    @property
    def y(self) -> float:
        return self._value[1]

    @property
    def z(self) -> float:
        return self._value[2]

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Vector3D):
            raise TypeError(
                f"Can only compare instances of {self.__class__.__name__} with instances of {self.__class__.__name__}. Got {other.__class__.__name__}"
            )
        return np.array_equal(self._value, other._value)

    def __neg__(self):
        return Vector3D(-self._value)

    def __add__(self, other: Union["Vector3D", float, int]) -> "Vector3D":
        value_to_add = other if isinstance(other, (float, int)) else other.value
        return Vector3D(self._value + value_to_add)

    def __sub__(self, other: Union["Vector3D", float, int]) -> "Vector3D":
        return self + (-other)

    def __abs__(self) -> float:
        return sqrt(self.x**2 + self.y**2 + self.z**2)

    def __truediv__(self, other: float) -> "Vector3D":
        return Vector3D(self._value / other)

    def cross(self, other: "Vector3D") -> "Vector3D":
        """
        Cross product between this vector and another.
        """
        return Vector3D(np.cross(self._value, other._value))

    def dot(self, other: "Vector3D") -> float:
        """
        Dot product between this vector and another.
        """
        return np.dot(self._value, other._value)

    def normalize(self) -> "Vector3D":
        """
        Returns a unit vector with the same direction of this vector.
        """
        norm = np.linalg.norm(self.value)
        if norm == 0:
            raise ValueError("Can't normalize Null vector")
        return Vector3D(self.value / norm)

    def copy(self) -> "Vector3D":
        return Vector3D(self._value.copy())

    def is_collinear_with(self, other: "Vector3D") -> bool:
        """
        Returns `True` if this vector is aligned (or very closely aligned) with
        another vector, regardless of direction. Returns `False` otherwise
        """
        try:
            dot_product = abs(self.normalize().dot(other.normalize()))
        except ValueError:
            return False

        return dot_product > COLLINEARITY_DOT_THRESHOLD

    def is_null_vector(self) -> bool:
        """
        Returns `True` if all coordinates of this vector are 0 (or very close to
        0), and `False` otherwise
        """
        return all(abs(i) < TOLERANCE for i in self._value)
