from typing import Tuple
import numpy as np
from .vector import Vector3D


class Point:
    """Wraps a 3D Vector which represents this point's position"""

    def __init__(self, position_vector: Vector3D) -> None:
        self._position = position_vector

    @staticmethod
    def xyz(x: float, y: float, z: float):
        return Point(Vector3D(np.array((x, y, z))))

    @staticmethod
    def average_of(*points: "Point") -> "Point":
        if len(points) < 1:
            raise ValueError(
                "Point.average_of() requires at least one point to be given as input."
            )
        average_point_sum = Vector3D.xyz(0, 0, 0)
        for point in points:
            average_point_sum += point.position
        return Point(average_point_sum / len(points))

    @property
    def x(self):
        return self._position.x

    @property
    def y(self):
        return self._position.y

    @property
    def z(self):
        return self._position.z

    @property
    def position(self):
        return self._position

    def __neg__(self):
        return Point(-self._position)

    def copy(self) -> "Point":
        return Point(self._position.copy())

    def line_to(self, other: "Point") -> "Line":
        """Returns a new `Line` which goes from this `Point` to `other`
        `Point`"""
        return Line(self, other)

    def vector_to(self, other: "Point") -> Vector3D:
        """Returns a new `Vector3D` which goes from this `Point` to `other`
        `Point`"""
        return other.position - self.position

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({self.x}, {self.y}, {self.z})"

    def __add__(self, other: Vector3D) -> "Point":
        return Point(self._position + other)

    def __sub__(self, other: Vector3D) -> "Point":
        return self + (-other)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Point):
            raise TypeError(
                f"Can only compare instances of {self.__class__.__name__} with instances of {self.__class__.__name__}. Got {other.__class__.__name__}"
            )
        return self._position == other._position


class Line:
    def __init__(self, point_from: Point, point_to: Point) -> None:
        self.point_from = point_from
        self.point_to = point_to
        if self.point_from == self.point_to:
            raise ValueError(
                "Tried to construct a Line instance from two Point instances that have the same coordinates"
            )

    @staticmethod
    def from_point_and_vector(starting_point: Point, vector: Vector3D) -> "Line":
        return Line(starting_point, starting_point + vector)

    def __abs__(self):
        return abs(self.point_from.vector_to(self.point_to))

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(from={self.point_from}, to={self.point_to})"

    def length(self):
        return abs(self)


class Triangle:
    def __init__(self, base: Point, point1: Point, point2: Point) -> None:
        self._point_base = base
        self._point_1 = point1
        self._point_2 = point2

        vector1 = self._point_base.vector_to(self._point_1)
        vector2 = self._point_base.vector_to(self._point_2)
        if vector1.is_null_vector() or vector2.is_null_vector():
            raise ValueError(
                f"Tried to construct a Triangle from three Point instances that share the same coordinates: {[base, point1, point2]}"
            )
        if vector1.is_collinear_with(vector2):
            raise ValueError(
                f"Tried to construct a Triangle from three Point instances that are collinear: {[base, point1, point2]}"
            )

    def normal(self, normalized: bool = True):
        """
        Returns the normal vector of this triangle. The normal is computed using
        a vector that goes from this triangle's first (base) point to its second
        point and then a vector that goes from its second point to its third
        point.

        This is the same order of points as returned by `Triangle.points()`
        """
        vector1 = self._point_base.vector_to(self._point_1)
        vector2 = self._point_1.vector_to(self._point_2)
        normal = np.cross(vector1.value, vector2.value)
        if normalized:
            normal = normal / np.linalg.norm(normal)
        normal = Vector3D(normal)
        return normal

    def points(self) -> Tuple[Point, Point, Point]:
        """
        Returns a tuple of all three `Point`s in the same order as given to the
        constructor
        """
        return (self._point_base.copy(), self._point_1.copy(), self._point_2.copy())

    def area(self) -> float:
        vector1 = self._point_base.vector_to(self._point_1)
        vector2 = self._point_base.vector_to(self._point_2)
        return abs(vector1.cross(vector2)) / 2

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({self._point_base}, {self._point_1}, {self._point_2})"
