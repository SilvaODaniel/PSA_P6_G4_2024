import math
from typing import List
from my_packages.robot.pose import RobotPose


def lerp_poses(
    start_pose: RobotPose,
    end_pose: RobotPose,
    max_spatial_diff: float,
    max_rotation_diff: float,
) -> List[RobotPose]:
    """
    Returns a list of poses which result from linearly interpolating from
    `start_pose` to `end_pose` such that `max_spatial_diff` and
    `max_rotation_diff` are respected. Note that `max_spatial_diff` is NOT the
    maximum euclidean distance between two points, it is simply the maximum
    amount each of the cartesian coordinates (x, y, z) can change. The same
    applies to `max_rotation_diff`.

    The last pose is guaranteed to be exactly the same as `end_pose`. The first
    pose is already different from `start_pose`, with the only exception being
    when `end_pose` and `start_pose` are the same, in which case this function
    returns a single element list with `end_pose` as its only element.
    """

    def get_step_count(*values: float, max_diff: float):
        steps = max([math.ceil(abs(i) / max_diff) for i in values])
        return max(steps, 1)

    x_start = start_pose.x_pos
    y_start = start_pose.y_pos
    z_start = start_pose.z_pos
    rx_start = start_pose.x_rot
    ry_start = start_pose.y_rot
    rz_start = start_pose.z_rot

    x_diff = end_pose.x_pos - start_pose.x_pos
    y_diff = end_pose.y_pos - start_pose.y_pos
    z_diff = end_pose.z_pos - start_pose.z_pos
    rx_diff = end_pose.x_rot - start_pose.x_rot
    ry_diff = end_pose.y_rot - start_pose.y_rot
    rz_diff = end_pose.z_rot - start_pose.z_rot

    steps = max(
        get_step_count(x_diff, y_diff, z_diff, max_diff=max_spatial_diff),
        get_step_count(rx_diff, ry_diff, rz_diff, max_diff=max_rotation_diff),
    )

    x_increments = x_diff / steps
    y_increments = y_diff / steps
    z_increments = z_diff / steps
    rx_increments = rx_diff / steps
    ry_increments = ry_diff / steps
    rz_increments = rz_diff / steps

    interpolated_poses = [
        RobotPose(
            x_pos=x_start + i * x_increments,
            y_pos=y_start + i * y_increments,
            z_pos=z_start + i * z_increments,
            x_rot=rx_start + i * rx_increments,
            y_rot=ry_start + i * ry_increments,
            z_rot=rz_start + i * rz_increments,
        )
        for i in range(1, steps)
    ]

    interpolated_poses.append(end_pose)

    return interpolated_poses


def lerp_list(
    start: List[float], end: List[float], max_diff: float
) -> List[List[float]]:
    """
    Returns a list of values which result from linearly interpolating from
    `start` to `end` such that `max_diff` is respected.

    The last element in the returned list is guaranteed to be exactly the same
    as `end`. The first element is already different from `start`, with the only
    exception being when `end` and `start` are the same, in which case this
    function returns a single element list with `end` as its only element.
    """

    def get_step_count(*values: float, max_diff: float):
        steps = max([math.ceil(abs(i) / max_diff) for i in values])
        return max(steps, 1)

    size = len(start)
    assert size == len(end)

    diffs = [end[i] - start[i] for i in range(size)]

    steps = get_step_count(*diffs, max_diff=max_diff)

    increments = [diffs[i] / steps for i in range(size)]

    interpolated_values = [
        [start_v + i * increment for start_v, increment in zip(start, increments)]
        for i in range(1, steps)
    ]

    interpolated_values.append(end)

    return interpolated_values
