from enum import Enum
import socket
from typing import Any, Dict, List, Literal, Optional, Tuple, Union, cast
import warnings
from my_packages.robot.interpolator import lerp_list, lerp_poses
from my_packages.robot.pose import RobotPose
from my_packages.utils.math import clip
from .elite_json import sendCMD
from time import perf_counter, sleep
from numpy import pi as PI

MAX_TRIES = 3
"""Number of times to retry to connect to Robot before aborting"""
MAX_SPATIAL_DIFF = 0.075  # mm/ms
"""
When setting a new target for the robot, this is the maximum value of how much
each consecutive position (x, y, z) can change per millisecond
"""
MAX_ROTATION_DIFF = 0.025 * PI / 180  # 0.025 deg/ms
"""
When setting a new target for the robot, this is the maximum value of how much
each consecutive euler rotation (rx, ry, rz) can change (in radians) per
millisecond
"""
MAX_JOINT_DIFF = 0.5 * PI / 180  # 0.025 deg/ms
"""
When setting a new target for the robot, this is the maximum value of how much
each joint can rotate (in radians) per millisecond
"""

TIME_BETWEEN_TARGET_CHANGES = 0.25
"""
Number of seconds to wait between each target change. Lower values will make
robot more responsive but will lead to stop constantly
"""

PoseOrAngleList = List[Union[RobotPose, List[float]]]


class RobotState(Enum):
    STOP = 0
    PAUSE = 1
    EMERGENCY_STOP = 2
    RUNNING = 3
    ALARM = 4
    COLLISION = 5


class ROBOT_BOUNDS:
    X = (-500, 500)
    Y = (-500, 500)
    Z = (200, 800)


class ETController:
    """
    A context manager which automatically opens and closes both the socket
    connection and issues cleanup commands to the robot.

    ### Args:
        - `ip` (str) and `port` (int) should be a valid address.

        - `log_responses` (bool, optional): If `True` all responses given
            from the robot will be recorded in a log file. Defaults to `False`.

    ### Example:
    ```python
    with ETController("127.0.0.1", 8055) as robot:
        robot.init_transparent_transmission(1, 1, 1)
    ```

    Which is effectively the same as:

    ```python
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(2)
    try:
        sock.connect(("127.0.0.1", 8055))
        robot = EC66Robot(sock, False)
        robot.init_transparent_transmission(1, 1, 1)
    finally:
        robot.stop()
        sock.close()
    ```

    """

    def __init__(
        self,
        ip: str,
        port: int,
        log_responses: bool = False,
    ) -> None:
        self._address = (ip, port)
        self._sock = None
        self._robot: Optional[EC66Robot] = None
        self._log_responses = log_responses

    def __enter__(self) -> "EC66Robot":
        tries = MAX_TRIES
        while tries > 0:

            try:
                self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                self._sock.settimeout(2)
                self._sock.connect(self._address)
                self._robot = EC66Robot(self._sock, log_responses=self._log_responses)
                return self._robot
            except Exception as e:
                self._sock = None
                print(f"Failed to connect due to error: {e}\nRetrying...")
                tries -= 1
                sleep(2)
        raise Exception(f"Failed to connect after {MAX_TRIES} tries.")

    def __exit__(self, *args):
        if self._robot is not None:
            self._robot.stop()

        if self._sock is not None:
            self._sock.close()


class EC66Robot:
    """
    Simplifies communication with the robot by using hard-coded and typed
    parameters for JSON-RPC 2.0

    "Unsafe" commands can still be executed by using the `run_raw()` method.
    """

    def __init__(self, connected_socket: socket.socket, log_responses: bool) -> None:
        self._sock = connected_socket
        self._log_responses = log_responses
        self._trajectory: Optional[PoseOrAngleList] = None
        self._last_trajectory_updated_at = 0
        self._t: Optional[float] = None
        self._transmission_state_params = None

    def run_raw(
        self, cmd: str, params: Optional[Dict[str, Any]] = None
    ) -> Tuple[bool, Optional[Any]]:
        """
        Runs unchecked command
        """
        return sendCMD(self._sock, cmd, params, log_responses=self._log_responses)

    def get_position(self) -> Optional[RobotPose]:
        """
        Returns the current position of the end effector
        """
        ok, v_origin = self.run_raw("getRobotPose")
        if ok and v_origin:
            return RobotPose(*v_origin)

    def get_joint_angles(self) -> Optional[List[float]]:
        """
        Returns the current position of the end effector
        """
        ok, pos = self.run_raw("getRobotPos")
        if not ok or pos is None:
            return None

        return pos

    def inverse_kinematic(
        self, target: RobotPose, unit: Literal["degrees", "radians"]
    ) -> Optional[List[float]]:
        """
        Computes inverse kinematics to achieve the `target`. If the pose is
        reachable, this method returns a list representing the joint angles, in
        degrees, that would lead to the `target`.

        If anything goes wrong, this method returns `None`
        """
        ok, target_pos = self.run_raw(
            "inverseKinematic",
            {
                "targetPose": target.to_tuple(),
                "unit_type": 1 if unit == "radians" else 0,
            },
        )
        if not ok or target_pos is None:
            return None

        return target_pos

    def add_joint_angles(self, joint_angles: List[float]):
        success, _ = self.run_raw(
            "tt_put_servo_joint_to_buf", {"targetPos": joint_angles}
        )
        return success

    def add_position(self, target: RobotPose) -> bool:
        """
        Adds position to the robot's position buffer. The given position is the
        end effector position.

        This function assumes the given position is "close enough" to the last
        given position, such that the robot will not violently snap to the new
        position. If you want to set a linear trajectory, use `set_target`
        instead.
        """
        target_pos = self.inverse_kinematic(target, unit="degrees")
        if target_pos is None:
            return False
        return self.add_joint_angles(target_pos)

    def init_transparent_transmission(
        self, lookahead: int, t: float, smoothness: float
    ) -> bool:
        self._transmission_state_params = {
            "lookahead": lookahead,
            "t": t,
            "smoothness": smoothness,
        }
        success, _ = self.run_raw(
            "transparent_transmission_init",
            {"lookahead": lookahead, "t": t, "smoothness": smoothness},
        )
        if success:
            self._t = t
        return success

    def get_transparent_transmission_state(self) -> Literal[None, 0, 1]:
        _, result = self.run_raw("get_transparent_transmission_state")
        return result

    def clear_queued_poses(self) -> bool:
        if self._transmission_state_params is None:
            return False
        success, _ = self.run_raw("tt_clear_servo_joint_buf", {"clear": 0})
        self.init_transparent_transmission(**self._transmission_state_params)
        self._trajectory = None
        return success

    def stop(self) -> bool:
        """
        Stops movement and also clears any buffered positions the robot was
        attempting to reach.
        """
        success_stop, _ = self.run_raw("stop")
        success_clear, _ = self.run_raw("tt_clear_servo_joint_buf", {"clear": 0})
        self._trajectory = None
        return success_clear and success_stop

    def set_target(
        self,
        target: RobotPose,
        interpolate: Literal["joint_angles", "positions"] = "positions",
    ):
        """
        Sets the given target as the current active trajectory. Calling this
        method also stops the robot from its current movement.

        The trajectory can be stepped through by repeatedly calling
        `move_to_target` trajectory until it returns `True`.

        `interpolate` can be either `"joint_angles"` or `"positions"`.
        `joint_angles` will lead to a smoother movement, but which might not be
        linear in terms of the trajectory. `positions`" will lead a striaght
        line trajectory, but which might lead to joint angles quickly changing.
        """
        if (
            perf_counter() - self._last_trajectory_updated_at
            < TIME_BETWEEN_TARGET_CHANGES
        ):
            return False

        if target.x_pos < ROBOT_BOUNDS.X[0] or target.x_pos > ROBOT_BOUNDS.X[1]:
            warnings.warn(
                f"X {target.x_pos} is outside expected range {ROBOT_BOUNDS.X}"
            )
            target.x_pos = clip(target.x_pos, within_range=ROBOT_BOUNDS.X)

        if target.y_pos < ROBOT_BOUNDS.Y[0] or target.y_pos > ROBOT_BOUNDS.Y[1]:
            warnings.warn(
                f"Y {target.y_pos} is outside expected range {ROBOT_BOUNDS.Y}"
            )
            target.y_pos = clip(target.y_pos, within_range=ROBOT_BOUNDS.Y)

        if target.z_pos < ROBOT_BOUNDS.Z[0] or target.z_pos > ROBOT_BOUNDS.Z[1]:
            warnings.warn(
                f"Z {target.z_pos} is outside expected range {ROBOT_BOUNDS.Z}"
            )
            target.z_pos = clip(target.z_pos, within_range=ROBOT_BOUNDS.Z)

        t = self._t or 20
        if interpolate == "positions":
            pose = self.get_position()
            if pose is None:
                return False
            max_spatial_diff = MAX_SPATIAL_DIFF * t
            max_rotation_diff = MAX_ROTATION_DIFF * t
            trajectory = lerp_poses(
                pose,
                target,
                max_spatial_diff=max_spatial_diff,
                max_rotation_diff=max_rotation_diff,
            )
        else:
            current_angles = self.get_joint_angles()

            if current_angles is None:
                return False

            target_angles = self.inverse_kinematic(target, unit="degrees")

            if target_angles is None:
                return False

            max_joint_diff = MAX_JOINT_DIFF * t

            trajectory = lerp_list(
                current_angles,
                target_angles,
                max_diff=max_joint_diff,
            )

        self._trajectory = cast(PoseOrAngleList, trajectory)
        self._last_trajectory_updated_at = perf_counter()
        return True

    def move_to_target(self) -> Tuple[bool, bool]:
        """
        Moves the robot a bit closer to the last set target pose (c.f.
        `set_target` with `flush` set to `False`) and eturns a tuple of booleans
        of the shape `(success, arrived)`.

        `success` indicates whether there was a problem with the operation and
        `arrived` notifies if the robot is positioned in the set target pose
        after this method call. If no target pose was set, this method also
        returns `True` for `arrived`.

        `arrived` being `True` always implies that `success` is true
        """
        if self._trajectory is None:
            self.arrived_to_target = True
            return True, True
        if len(self._trajectory) < 1:
            self.arrived_to_target = True
            self._trajectory = None
            return True, True

        pose_or_angles = self._trajectory.pop(0)

        if isinstance(pose_or_angles, RobotPose):
            success = self.add_position(pose_or_angles)
        else:
            success = self.add_joint_angles(pose_or_angles)

        if not success:
            self._trajectory.insert(0, pose_or_angles)
            self.arrived_to_target = False
            return False, False

        if len(self._trajectory) < 1:
            self._trajectory = None
            self.arrived_to_target = True
            return True, True

        self.arrived_to_target = False
        return True, False

    def clear_alarm(self):
        success, result = self.run_raw("clearAlarm")

        if isinstance(result, bool):
            return result

        return success

    def get_robot_state(self) -> Optional[RobotState]:
        _, result = self.run_raw("getRobotState")

        for state in RobotState:
            if result == state.value:
                return state

        return None
