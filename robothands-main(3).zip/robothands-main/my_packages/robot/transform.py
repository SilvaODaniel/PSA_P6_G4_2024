from my_packages.robot.pose import RobotPose
from task.common import FeaturesPayload


class CoordinatesTransformer:
    def __init__(self) -> None:
        self._pos_factor = 1
        self._x_offset = 0
        self._y_offset = 0
        self._z_offset = 0

        self._rotation_factor = 0
        self._rx_offset = 91
        self._ry_offset = -1
        self._rz_offset = 179

    def add_position_factor(self, factor: float):
        self._pos_factor = factor

    def adjust_xyz_offsets_to_pose(self, pose: RobotPose, payload: FeaturesPayload):
        x, y, z = [coord * self._pos_factor for coord in payload.center]
        self._x_offset = pose.x_pos - x
        self._y_offset = pose.y_pos - y
        self._z_offset = pose.z_pos - z

    def apply(self, payload: FeaturesPayload):
        x, y, z = (
            pos * self._pos_factor + offset
            for pos, offset in zip(
                payload.center, (self._x_offset, self._y_offset, self._z_offset)
            )
        )
        rx, ry, rz = (
            pos * self._rotation_factor + offset
            for pos, offset in zip(
                payload.normal, (self._rx_offset, self._ry_offset, self._rz_offset)
            )
        )
        return RobotPose(x_pos=x, y_pos=y, z_pos=z, x_rot=rx, y_rot=ry, z_rot=rz)
