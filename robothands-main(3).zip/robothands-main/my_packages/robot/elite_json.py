import json
import os
from socket import socket
import traceback
from typing import Any, Dict, Optional, Tuple

LOG_FILE_PATH = os.path.join(os.path.abspath(os.curdir), "logs", "elite_responses.log")


def _log_response(request: str, response: str):
    try:
        with open(LOG_FILE_PATH, "a") as f:
            if not request.endswith("\n"):
                request += "\n"
            log_str = f"\nFor request\n\t{request}Received response:\n\t{response}"
            if not log_str.endswith("\n"):
                log_str += "\n"
            f.write(log_str)
    except Exception:
        pass


def sendCMD(
    sock: socket,
    cmd: str,
    params: Optional[Dict[str, Any]] = None,
    log_responses: bool = False,
) -> Tuple[bool, Optional[Any]]:
    """
    Sends command to `sock`. `cmd` is a string for the method to call, and
    `params` are the parameters to be used for that method, as is expected by
    JSON-RPC 2.0

    If `log_responses` is `True`, this function will automatically log all
    requests and responses to a log file
    """
    params = params or {}
    sendStr = (
        json.dumps(
            {"method": cmd, "params": params, "jsonrpc": "2.0", "id": 1},
            separators=(",", ":"),
        )
        + "\n"
    )
    try:
        sock.sendall(bytes(sendStr, "utf-8"))
        ret = sock.recv(1024)
        recvStr = str(ret, "utf-8")

        if log_responses:
            _log_response(request=sendStr, response=recvStr)

        jdata = json.loads(recvStr)

        if "result" in jdata:
            result = json.loads(jdata["result"])
            return True, result

        elif "error" in jdata:
            error = jdata["error"]

            if isinstance(error, str):
                print(error)
                error = json.loads(error)

            elif isinstance(error, dict):
                message = error.get("message", None)
                if message is not None:
                    print(message)

            else:
                print(error)

            return False, error

        else:
            print(
                f"Unexpected response payload structure (expected either 'error' or 'result'): {jdata}"
            )
            return False, None

    except Exception as e:
        traceback.print_exc()
        return False, {"message": str(e)}
