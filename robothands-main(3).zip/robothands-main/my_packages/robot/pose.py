from dataclasses import dataclass


@dataclass
class RobotPose:
    """
    Represents the end effector's position and rotation
    """

    x_pos: float
    """In milimeters"""
    y_pos: float
    """In milimeters"""
    z_pos: float
    """In milimeters"""
    x_rot: float
    """In radians"""
    y_rot: float
    """In radians"""
    z_rot: float
    """In radians"""

    def to_tuple(self):
        return self.x_pos, self.y_pos, self.z_pos, self.x_rot, self.y_rot, self.z_rot
