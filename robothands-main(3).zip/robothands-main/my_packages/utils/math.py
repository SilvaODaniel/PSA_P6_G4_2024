from typing import Tuple


Range = Tuple[float, float]


def clip(value: float, within_range: Range) -> float:
    """
    Returns `value` if it is withing the given `Range`. Else, returns the
    clipped value to the nearest Range bound

    ## Example
    ```
    assert clip(value=3, within_range=(1.5, 6)) == 3
    assert clip(value=7, within_range=(1.5, 6)) == 6
    assert clip(value=1, within_range=(1.5, 6)) == 1.5
    ```
    """
    min_v, max_v = min(within_range), max(within_range)
    return min(max(value, min_v), max_v)


def normalize_in_range(value: float, input_range: Range, clip_result: bool = False):
    """
    Given a `value`, normalize it within the `input_range` range such that if
    `value` is within that range, this function returns a value between 0 and 1.
    If `clip`, the returned value is guaranteed to be within the `[0, 1]` range,
    otherwise if `value` is outside the range, than this function will return a
    value outside the `[0, 1]` range

    ## Example
    ```python
    assert normalize_in_range(value=0, input_range=(0, 100)) == 0
    assert normalize_in_range(value=100, input_range=(0, 100)) == 1
    assert normalize_in_range(value=50, input_range=(0, 100)) == 0.5
    assert normalize_in_range(value=200, input_range=(0, 100)) == 2
    assert normalize_in_range(value=200, input_range=(0, 100), clip_result=True) == 1
    ```
    """
    start_v, end_v = input_range
    delta = end_v - start_v
    result = (value - start_v) / delta

    if clip_result:
        result = clip(result, (0.0, 1.0))

    return result
