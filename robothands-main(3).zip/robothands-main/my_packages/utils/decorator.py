from typing import Type, TypeVar

T = TypeVar("T", bound=Type)


class StubInstantiationException(Exception): ...


def stub(cls: T) -> T:
    """Decorates a class to indicate it is merely used for typing objects. This decorator prevents a class from being instantiated"""
    if not isinstance(cls, type):
        raise TypeError("@stub decorator can only be applied to classes.")

    def cstm_new(*a, **kw):
        raise StubInstantiationException("You cannot instantiate stub classes.")

    cls.__new__ = cstm_new
    return cls
