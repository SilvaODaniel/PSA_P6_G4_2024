from typing import Tuple, Union
from my_packages.geometry3d.shape import Line, Point, Triangle


Color = Tuple[float, float, float]
Coord2D = Tuple[float, float]
PointLike = Union[Coord2D, Point]
LineLike = Union[Tuple[Coord2D, Coord2D], Line]
TriangleLike = Union[Tuple[Coord2D, Coord2D, Coord2D], Triangle]
SquareLike = Tuple[Coord2D, Coord2D, Coord2D, Coord2D]
ImgPoint = Tuple[int, int]
