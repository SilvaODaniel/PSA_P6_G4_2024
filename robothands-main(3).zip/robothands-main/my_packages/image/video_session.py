import cv2
from .window_controller import WindowController


class VideoSession:
    """
    Starts recording and capturing keypresses when iterated upon. Iteration
    stops when a given stop key is pressed. Iteration gives back a frame,
    keypresses, and an instante of `WindowController` which you may use to show
    the image and also manipulate it.

    ## Example
    ```python
    for frame, controller, keypress in VideoSession("q"):
        if keypress == "c":
            print("User pressed 'c'")
        print(f"FPS: {controller.fps()}")
        controller.show()
    ```
    """

    def __init__(
        self, stop_key: str, window_name: str = "Display", flip_horizontal: bool = False
    ) -> None:
        if len(stop_key) != 1:
            raise ValueError("stop_key should be a string of size 1 (i.e. a character)")

        self._stop_key = ord(stop_key)
        self._cap = cv2.VideoCapture(0)
        self._cap.set(cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)
        self._controller = WindowController(window_name)
        self._flip_horizontal = flip_horizontal

    def set_width(self, width: int):
        self._cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)

    def set_height(self, height: int):
        self._cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)

    def __iter__(self):
        key_press = -1
        success = True

        while self._cap.isOpened() and key_press != self._stop_key:
            pressed_letter = None
            key_press = cv2.pollKey() & 0xFF
            if chr(key_press).isalpha():
                pressed_letter = chr(key_press)
            success, frame = self._cap.read()

            if self._flip_horizontal:
                frame = cv2.flip(frame, 1)

            if not success:
                break
            self._controller.overwrite_frame(frame)
            yield frame, self._controller, pressed_letter

        self._cap.release()
        cv2.destroyWindow(self._controller.window_name)
