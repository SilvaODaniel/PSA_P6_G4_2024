from typing import Tuple
import cv2
from cv2.typing import MatLike
import numpy as np
from time import time as now
from my_packages.utils.math import clip
from .types import *


class WindowController:
    """
    Represents a Window where images can be displayed and different commonplace
    annotations to the image can be added.

    Although this class is mainly meant to be used with `VideoSession` you can
    also use it to display any image you want (through its `overwrite_frame()`
    method) and manipulate the frame before displaying it.
    """

    def __init__(self, window_name: str) -> None:
        self.window_name = window_name
        self._frame_lag = 0.0
        self._last_shown = now()
        self._fps_smoothing = 0.9

        # temporary dummy value: a single black pixel
        self._frame: MatLike = np.zeros((1, 1, 3))

    def fps(self):
        if self._frame_lag == 0:
            return 0
        return 1 / self._frame_lag

    def overwrite_frame(self, frame: MatLike):
        """Overwrites image to display on next `show()` call."""
        self._frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    def show(self):
        """Displays currently set image"""
        delta = now() - self._last_shown
        self._last_shown = now()

        self._frame_lag = (self._frame_lag * self._fps_smoothing) + (
            delta * (1.0 - self._fps_smoothing)
        )
        cv2.imshow(self.window_name, cv2.cvtColor(self._frame, cv2.COLOR_RGB2BGR))

    def _get_scaled_coords(self, coords: PointLike) -> ImgPoint:
        if isinstance(coords, Point):
            x, y = coords.x, coords.y
        else:
            x, y = coords
        y_max, x_max, _ = self._frame.shape
        x_scaled = int(clip(x * x_max, (0, x_max)))
        y_scaled = int(clip(y * y_max, (0, y_max)))
        return x_scaled, y_scaled

    def add_point(
        self,
        point: PointLike,
        color: Color = (255, 0, 0),
        size: int = 5,
    ):
        """Adds a single point to the currently set image"""
        coords = self._get_scaled_coords(point)
        self._frame = cv2.circle(
            img=self._frame,
            center=coords,
            radius=1,
            color=color,
            thickness=size,
        )

    def add_text(
        self,
        text: str,
        point: PointLike,
        color: Color = (255, 255, 255),
        size: float = 1.0,
        thickness: int = 2,
    ):
        """Adds text to the currently set image"""
        coords = self._get_scaled_coords(point)
        self._frame = cv2.putText(
            img=self._frame,
            text=text,
            org=coords,
            fontFace=cv2.FONT_HERSHEY_SIMPLEX,
            fontScale=size,
            color=color,
            thickness=thickness,
        )

    def _get_scaled_coords_from_line(self, line: LineLike) -> Tuple[ImgPoint, ImgPoint]:
        if isinstance(line, Line):
            from_point = line.point_from
            to_point = line.point_to
        else:
            from_point = line[0]
            to_point = line[1]

        to_coords = self._get_scaled_coords(to_point)
        from_coords = self._get_scaled_coords(from_point)
        return from_coords, to_coords

    def _get_scaled_coords_from_tri(
        self, tri: TriangleLike
    ) -> Tuple[ImgPoint, ImgPoint, ImgPoint]:
        if isinstance(tri, Triangle):
            p1, p2, p3 = tri.points()
        else:
            p1, p2, p3 = tri[0], tri[1], tri[2]

        c1, c2, c3 = (
            self._get_scaled_coords(p1),
            self._get_scaled_coords(p2),
            self._get_scaled_coords(p3),
        )
        return c1, c2, c3

    def add_arrow(
        self,
        line: LineLike,
        color: Color = (0, 255, 0),
        thickness: int = 5,
    ):
        """Adds an arrow to the currently set image"""
        from_coords, to_coords = self._get_scaled_coords_from_line(line)

        self._frame = cv2.arrowedLine(
            img=self._frame,
            pt1=from_coords,
            pt2=to_coords,
            color=color,
            thickness=thickness,
            tipLength=0.25,
        )

    def add_line(
        self,
        line: LineLike,
        color: Color = (0, 255, 0),
        thickness: int = 5,
    ):
        """Adds a line to the currently set image"""
        from_coords, to_coords = self._get_scaled_coords_from_line(line)

        self._frame = cv2.line(
            img=self._frame,
            pt1=from_coords,
            pt2=to_coords,
            color=color,
            thickness=thickness,
        )

    def add_tri(
        self, tri: TriangleLike, color: Color = (0, 255, 0), alpha: float = 0.5
    ):
        """Adds a triangle to the currently set image"""

        self._add_poli_pixel(
            *self._get_scaled_coords_from_tri(tri), color=color, alpha=alpha
        )

    def add_poli(self, *poli_points: Coord2D, color: Color, alpha: float):
        self._add_poli_pixel(
            *(self._get_scaled_coords(point) for point in poli_points),
            color=color,
            alpha=alpha,
        )

    def _add_poli_pixel(self, *poli_points: ImgPoint, color: Color, alpha: float):
        if len(poli_points) < 3:
            raise ValueError(
                f"Poligon needs at least 3 points, found {len(poli_points)}."
            )

        points = [np.array(poli_points).astype(np.int32)]
        img_cpy = None
        if alpha < 1.0:
            img_cpy = self._frame.copy()
        self._frame = cv2.fillPoly(img=self._frame, pts=points, color=color)
        if img_cpy is not None:
            self._frame = cv2.addWeighted(
                self._frame, alpha, img_cpy, 1 - alpha, 0, img_cpy
            )
