from typing import Mapping
from my_packages.geometry3d.shape import Line, Point, Triangle
from my_packages.hands.consts import HandPoint
from my_packages.hands.features import Features
from my_packages.image.window_controller import WindowController
from numpy import pi as PI


def _get_2d_center(results: Features):
    return Point.average_of(
        results.original_data.get_pos(HandPoint.WRIST, "Image"),
        results.original_data.get_pos(HandPoint.INDEX_KUCKLE, "Image"),
        results.original_data.get_pos(HandPoint.PINKY_KUCKLE, "Image"),
    )


def show_center(window: WindowController, results: Features):
    """
    Displays a dot at the hand's palm's center.
    """
    window.add_point(_get_2d_center(results), size=10)


def show_normal(window: WindowController, results: Features):
    """
    Displays an arrow pointing to where the palm is pointing towards.
    """
    center = _get_2d_center(results)
    normal = results.normal
    if center and normal:
        window.add_arrow(
            Line.from_point_and_vector(starting_point=center, vector=normal)
        )


def show_side(window: WindowController, results: Features):
    """
    Displays text with whether the detected hand is left or right.
    """
    center = _get_2d_center(results)
    side = results.original_data.side

    if center and side:
        window.add_text(side, center)


def show_xyz(window: WindowController, results: Features):
    """
    Displays text on the corner showing the `(x, y, z)` coordinates of the
    hand's center. These coordinates are given in the camera's frame of
    reference.
    """
    hand_center = results.center

    text_line_size = 0.07

    origin = (0.02, 0.35)
    window.add_text(f"X(mm): {hand_center.x*1000:.1f}", origin)

    origin = (origin[0], origin[1] + text_line_size)
    window.add_text(f"Y(mm): {hand_center.y*1000:.1f}", origin)

    origin = (origin[0], origin[1] + text_line_size)
    window.add_text(f"Z(mm): {hand_center.z*1000:.1f}", origin)


def show_rxyz(window: WindowController, results: Features):
    """
    Displays text on the corner showing the `(x, y, z)` coordinates of the
    hand's center. These coordinates are given in the camera's frame of
    reference.
    """
    text_line_size = 0.07
    normal = results.normal
    origin = (0.02, 0.56)
    window.add_text(f"Rx(deg): {normal.x*180/PI:.1f}", origin)

    origin = (origin[0], origin[1] + text_line_size)
    window.add_text(f"Ry(deg): {normal.y*180/PI:.1f}", origin)

    origin = (origin[0], origin[1] + text_line_size)
    window.add_text(f"Rz(deg): {normal.z*180/PI:.1f}", origin)


def show_palm(window: WindowController, results: Features):
    """
    Displays a triangle which represents the detected hand's palm.
    """
    original_data = results.original_data

    p1 = original_data.get_pos(HandPoint.WRIST, "Image")
    p2 = original_data.get_pos(HandPoint.INDEX_KUCKLE, "Image")
    p3 = original_data.get_pos(HandPoint.PINKY_KUCKLE, "Image")

    if p1 is None or p2 is None or p3 is None:
        return

    palm = Triangle(p1, p2, p3)

    window.add_tri(palm)


def show_fps(window: WindowController):
    """
    Displays frames per second on the corner of the screen.
    """
    window.add_text(f"{window.fps():.0f}", (0.05, 0.95))


def show_instructions(window: WindowController, keybinds: Mapping[str, str]):
    """
    Displays text on the corner showing instructions based on the provided
    `keybinds`
    """
    key_command_pairs = [(k, v) for k, v in keybinds.items()]

    text_line_size = 0.07
    origin = (0.02, 0.05)

    for key, command in key_command_pairs:
        window.add_text(f"{key} - {command}", origin)
        origin = (origin[0], origin[1] + text_line_size)


def show_paused(window: WindowController):
    """
    Shows a pause symbol on the top right corner
    """
    left_x = 0.92
    top_y = 0.05

    width = 0.01
    height = 0.05

    color = (255, 0, 0)
    alpha = 1.0

    window.add_poli(
        (left_x + width, top_y),
        (left_x + width, top_y + height),
        (left_x, top_y + height),
        (left_x, top_y),
        alpha=alpha,
        color=color,
    )

    left_x += width * 2

    window.add_poli(
        (left_x + width, top_y),
        (left_x + width, top_y + height),
        (left_x, top_y + height),
        (left_x, top_y),
        alpha=alpha,
        color=color,
    )


def show_play(window: WindowController):
    """
    Shows a play symbol on the top right corner
    """
    left_x = 0.92
    top_y = 0.05
    width = 0.03
    height = 0.05
    window.add_poli(
        (left_x, top_y),
        (left_x + width, top_y + height / 2),
        (left_x, top_y + height),
        alpha=1.0,
        color=(0, 255, 0),
    )


def show_detections(window: WindowController, results: Features):
    """
    Invokes (in this order):
    - `show_pinch()`
    - `show_palm()`
    - `show_normal()`
    - `show_center()`
    - `show_side()`
    - `show_xyz()`
    """
    show_palm(window, results)
    show_normal(window, results)
    show_center(window, results)
    show_side(window, results)
    show_xyz(window, results)
    show_rxyz(window, results)
