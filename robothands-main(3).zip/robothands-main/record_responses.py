from time import sleep, perf_counter as now
from tqdm import tqdm as progress_bar
from my_packages.robot.interface import ETController

T_MILLIS = 20
T_SECS = T_MILLIS / 1000

with ETController(ip="localhost", port=8055, log_responses=True) as robot:

    try:
        pose = robot.get_position()
        robot.init_transparent_transmission(200, 20, 0.5)
        print("Sent position")
        pose = robot.get_position()
        if pose is not None:
            print(pose)

            for i in progress_bar(range(100)):
                start = now()
                pose.x_rot += 0.1
                pose.y_rot += 0.1
                pose.z_rot += 0.1
                robot.add_position(pose)
                leftover = T_SECS - (now() - start)
                if leftover > 0:
                    sleep(leftover)

    except KeyboardInterrupt:
        pass
    robot.stop()
