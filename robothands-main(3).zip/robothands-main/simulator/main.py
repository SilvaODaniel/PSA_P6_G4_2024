from typing import Literal
import roboticstoolbox as rtb
import swift
from kinematics import get_angles_for_endpoint, get_forward_kinematics
import request as r
from response import Response
from server import start_server
from numpy import pi as PI
import numpy as np


STOP_STATE = 0
RUNNING_STATE = 3
OFF = 0
ON = 1

robot_state: Literal[0, 3] = STOP_STATE
robot_speed: float = 75
transparent_transmission_state = OFF


def stop(request: r.StopRequest) -> Response:
    return Response.ok()


def get_transparent_transmission_state(
    request: r.GetTransparentTransmissionStateRequest,
) -> Response:
    return Response.ok(transparent_transmission_state)


def start_transparent_transmission(
    request: r.TransparentTransmissionInitRequest,
) -> Response:
    global transparent_transmission_state
    transparent_transmission_state = ON
    return Response.ok()


def put_servo_joint_to_buffer(
    request: r.TTPutServoJointToBufRequest, robot: rtb.Robot
) -> Response:
    if transparent_transmission_state == OFF:
        return Response.error(
            "Failed to put servo joint to buf, check transparent_transmission_state or robot state is not error."
        )
    robot.q = np.array(request.params.targetPos) * PI / 180
    return Response.ok()


def clear_servo_joint_buffer(request: r.TTClearServoJointBufRequest) -> Response:
    return Response.ok()


def get_robot_pose(request: r.GetRobotPoseRequest, robot: rtb.Robot) -> Response:
    T = get_forward_kinematics(robot)
    rx, ry, rz = T.eul("rad")
    return Response.ok((T.x * 1000, T.y * 1000, T.z * 1000, rx, ry, rz))


def get_robot_joints(request: r.GetRobotPosRequest, robot: rtb.Robot) -> Response:
    a1, a2, a3, a4, a5, a6 = robot.q * 180 / PI
    return Response.ok((a1, a2, a3, a4, a5, a6))


def get_inverse_kinematics(
    request: r.InverseKinematicRequest, robot: rtb.Robot
) -> Response:
    target_pose = request.params.targetPose
    x, y, z, rx, ry, rz = target_pose
    x /= 1000
    y /= 1000
    z /= 1000
    target_pos = get_angles_for_endpoint(robot, x, y, z, rx, ry, rz)

    if target_pos is None:
        return Response.error("Failed to resolve inverse kinematics")

    target_pos *= 180 / PI
    a1, a2, a3, a4, a5, a6 = target_pos
    return Response.ok((a1, a2, a3, a4, a5, a6))


def get_robot_state(request: r.GetRobotStateRequest) -> Response:
    return Response.ok(robot_state)


def get_speed(request: r.GetSpeedRequest) -> Response:
    return Response.ok(robot_speed)


def set_speed(request: r.SetSpeedRequest) -> Response:
    global robot_speed
    robot_speed = request.params.value
    return Response.ok()


def clear_alarm(request: r.ClearAlarmRequest) -> Response:
    return Response.ok()


def start_swift():
    env = swift.Swift()
    env.launch(realtime=True)

    # Create a puma in the default zero pose
    robot = rtb.models.UR3()
    robot.q = robot.qz

    env.add(robot, robot_alpha=True, collision_alpha=False)
    return env, robot


def get_initial_position():
    return 0.3, 0.3, 0.3, 0, 0, 0


def handle_request(concrete_request, robot) -> Response:
    if isinstance(concrete_request, r.SetSpeedRequest):
        return set_speed(concrete_request)

    if isinstance(concrete_request, r.StopRequest):
        return stop(concrete_request)

    if isinstance(concrete_request, r.GetTransparentTransmissionStateRequest):
        return get_transparent_transmission_state(concrete_request)

    if isinstance(concrete_request, r.TTPutServoJointToBufRequest):
        return put_servo_joint_to_buffer(concrete_request, robot)

    if isinstance(concrete_request, r.TransparentTransmissionInitRequest):
        return start_transparent_transmission(concrete_request)

    if isinstance(concrete_request, r.TTClearServoJointBufRequest):
        return clear_servo_joint_buffer(concrete_request)

    if isinstance(concrete_request, r.GetRobotPoseRequest):
        return get_robot_pose(concrete_request, robot)

    if isinstance(concrete_request, r.GetRobotPosRequest):
        return get_robot_joints(concrete_request, robot)

    if isinstance(concrete_request, r.GetSpeedRequest):
        return get_speed(concrete_request)

    if isinstance(concrete_request, r.InverseKinematicRequest):
        return get_inverse_kinematics(concrete_request, robot)

    if isinstance(concrete_request, r.GetRobotStateRequest):
        return get_robot_state(concrete_request)

    if isinstance(concrete_request, r.ClearAlarmRequest):
        return clear_alarm(concrete_request)

    print(f"Unhandled request: {concrete_request}")
    return Response.error("Server could not handle request")


if __name__ == "__main__":
    request_queue, response_queue = start_server(8055)

    env, robot = start_swift()

    while True:
        request = request_queue.poll()
        if request is not None:
            response = handle_request(request.root, robot)
            response_queue.put(response)
        env.step()
