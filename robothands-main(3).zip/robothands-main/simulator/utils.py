from queue import Empty, Full, Queue
from typing import Generic, Optional, Tuple, Type, TypeVar


T = TypeVar("T")


class TypedQueue(Generic[T]):
    def __init__(self, maxsize: int = 0) -> None:
        self._queue = Queue(maxsize=maxsize)

    def get(self, timeout: Optional[float] = None) -> T:
        return self._queue.get(timeout=timeout)

    def poll(self) -> Optional[T]:
        try:
            return self._queue.get_nowait()
        except Empty:
            return None

    def put(self, item: T, timeout: Optional[float] = None):
        self._queue.put(item, timeout=timeout)

    def put_nowait(self, item: T) -> bool:
        try:
            self._queue.put_nowait(item)
            return True
        except Full:
            return False


class ConsumerQueue(Generic[T]):
    def __init__(self, queue: TypedQueue[T]) -> None:
        self._queue = queue

    def get(self, timeout: Optional[float] = None) -> T:
        return self._queue.get(timeout=timeout)

    def poll(self) -> Optional[T]:
        return self._queue.poll()


class ProducerQueue(Generic[T]):
    def __init__(self, queue: TypedQueue[T]) -> None:
        self._queue = queue

    def put(self, item: T, timeout: Optional[float] = None):
        self._queue.put(item, timeout=timeout)


def create_consumer_producer_pair(
    t: Type[T],
    max_queue_size: int = 0,
) -> Tuple[ProducerQueue[T], ConsumerQueue[T]]:
    queue = TypedQueue(maxsize=max_queue_size)
    return ProducerQueue(queue), ConsumerQueue(queue)
