from typing import List, Literal, Optional, Tuple, Union
from pydantic import BaseModel, Field, RootModel

CartesianPose = Tuple[float, float, float, float, float, float]
Joints = Tuple[float, float, float, float, float, float, float]
Result = Union[bool, int, float, CartesianPose, Joints]


class ResponseMetadata(BaseModel):
    jsonrpc: str = Field(
        "2.0",
    )
    id: int


class ResultModel(RootModel):
    root: Result


class OkResponse(ResponseMetadata):
    result: str

    @classmethod
    def from_result(cls, result: Optional[Result] = None):
        if result is None:
            result = True
        return cls(
            jsonrpc="2.0", id=1, result=ResultModel(root=result).model_dump_json()
        )

    def parse_result(self) -> Result:
        return parse_result(self.result)


class MethodNotFoundResponseBody(BaseModel):
    code: Literal[-32601]
    message: Literal["Method not found."]


class ErrorResponseBody(BaseModel):
    code: Literal[-32693]
    message: str


class ErrorResponse(ResponseMetadata):
    error: Union[ErrorResponseBody, MethodNotFoundResponseBody]


ResponseKind = Union[OkResponse, ErrorResponse]


class Response(RootModel):
    root: ResponseKind

    @classmethod
    def error(cls, error_msg: str):
        return cls(
            root=ErrorResponse(
                jsonrpc="2.0",
                id=1,
                error=ErrorResponseBody(code=-32693, message=error_msg),
            )
        )

    @classmethod
    def ok(cls, result: Optional[Result] = None):
        return cls(root=OkResponse.from_result(result))


def parse(json_str: str) -> ResponseKind:
    return Response.model_validate_json(json_str).root


def parse_result(json_str: str) -> Result:
    return ResultModel.model_validate_json(json_str).root


if __name__ == "__main__":
    responses: List[ResponseKind] = []
    errors = set()
    with open("logs/elite_resp.log", "r") as f:
        for i in f.readlines():
            try:
                responses.append(parse(i))
            except Exception as e:
                errors.add(str(e) + "\n" + i)

    with open("logs/elite_resp_recreated.log", "w") as f:
        for resp in responses:
            if isinstance(resp, OkResponse):
                resp.parse_result()
                remade_response = OkResponse(
                    jsonrpc=resp.jsonrpc, id=resp.id, result=resp.result
                )
                f.write(remade_response.model_dump_json())
            else:
                f.write(
                    ErrorResponse(
                        jsonrpc=resp.jsonrpc, id=resp.id, error=resp.error
                    ).model_dump_json()
                )
            f.write("\n")
