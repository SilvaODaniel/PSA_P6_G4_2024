from typing import Literal, Optional, Tuple, Union
from pydantic import BaseModel, RootModel

CartesianPose = Tuple[float, float, float, float, float, float]
Joints = Tuple[float, float, float, float, float, float]


class RequestMetadata(BaseModel):
    method: str
    jsonrpc: Literal["2.0"]
    id: int


class Empty(BaseModel):
    ...

    class Config:
        extra = "forbid"


class SetSpeedRequestParams(BaseModel):
    value: float


class SetSpeedRequest(RequestMetadata):
    method: Literal["setSpeed"]
    params: SetSpeedRequestParams


class GetSpeedRequest(RequestMetadata):
    method: Literal["getSpeed"]
    params: Empty


class StopRequest(RequestMetadata):
    method: Literal["stop"]
    params: Empty


class GetTransparentTransmissionStateRequest(RequestMetadata):
    method: Literal["get_transparent_transmission_state"]
    params: Empty


class TTPutServoJointToBufRequestParams(BaseModel):
    targetPos: Joints


class TTPutServoJointToBufRequest(RequestMetadata):
    method: Literal["tt_put_servo_joint_to_buf"]
    params: TTPutServoJointToBufRequestParams


class TransparentTransmissionInitRequestParams(BaseModel):
    lookahead: int
    t: int
    smoothness: float
    response_enable: Optional[Literal[1, 0]] = None


class TransparentTransmissionInitRequest(RequestMetadata):
    method: Literal["transparent_transmission_init"]
    params: TransparentTransmissionInitRequestParams


class TTClearServoJointBufRequestParams(BaseModel):
    clear: int


class TTClearServoJointBufRequest(RequestMetadata):
    method: Literal["tt_clear_servo_joint_buf"]
    params: TTClearServoJointBufRequestParams


class GetRobotPosRequest(RequestMetadata):
    method: Literal["getRobotPos"]
    params: Empty


class GetRobotPoseRequest(RequestMetadata):
    method: Literal["getRobotPose"]
    params: Empty


class InverseKinematicRequestParams(BaseModel):
    targetPose: CartesianPose


class InverseKinematicRequest(RequestMetadata):
    method: Literal["inverseKinematic"]
    params: InverseKinematicRequestParams


class GetRobotStateRequest(RequestMetadata):
    method: Literal["getRobotState"]
    params: Empty


class ClearAlarmRequest(RequestMetadata):
    method: Literal["clearAlarm"]
    params: Empty


ConcreteRequest = Union[
    SetSpeedRequest,
    StopRequest,
    GetTransparentTransmissionStateRequest,
    TTPutServoJointToBufRequest,
    TransparentTransmissionInitRequest,
    TTClearServoJointBufRequest,
    GetRobotPoseRequest,
    GetRobotPosRequest,
    GetSpeedRequest,
    InverseKinematicRequest,
    GetRobotStateRequest,
    ClearAlarmRequest,
]


class Request(RootModel):
    root: ConcreteRequest


def parse(json_str: str) -> ConcreteRequest:
    return Request.model_validate_json(json_str).root


if __name__ == "__main__":
    requests = []
    with open("logs/elite_req.log", "r") as f:
        for i in f.readlines():
            requests.append(parse(i))
