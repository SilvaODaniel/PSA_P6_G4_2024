from dataclasses import dataclass
from typing import Optional, Tuple, cast
from spatialmath import SE3
import roboticstoolbox as rtb
from numpy.typing import NDArray
import numpy as np

IK_RESIDUAL_THRESHOLD = 1e-6
"""
Maximum allowed residual when resolving inverse kinematics using
Levenberg-Marquadt Numerical Inverse Kinematics Solver. Higher means more
accurate results with higher tendency for solutions to be deemed unsuccessful
"""


def translate(x: float, y: float, z: float) -> SE3:
    return SE3.Trans(x, y, z)  # type: ignore


def rotate(rx: float, ry: float, rz: float) -> SE3:
    return SE3.Rx(rx) * SE3.Ry(ry) * SE3.Rz(rz)


def get_inverse_kinematics(
    robot: rtb.Robot, transformation_matrix: SE3
) -> Optional[NDArray[np.float64]]:
    joint_angles, _, _, _, residual = robot.ik_LM(  # type: ignore
        transformation_matrix, q0=robot.q, tol=IK_RESIDUAL_THRESHOLD
    )
    joint_angles = cast(NDArray, joint_angles)
    joint_angles = joint_angles.astype(np.float64)
    if np.isnan(joint_angles).any() or residual > IK_RESIDUAL_THRESHOLD:
        joint_angles = None
    return joint_angles


def get_forward_kinematics(
    robot: rtb.Robot, joint_angles: Optional[NDArray[np.float64]] = None
) -> SE3:
    if joint_angles is None:
        joint_angles = robot.q
    return robot.fkine(joint_angles)  # type: ignore


def get_angles_for_endpoint(
    robot: rtb.Robot,
    x: float,
    y: float,
    z: float,
    rx: float,
    ry: float,
    rz: float,
) -> Optional[NDArray[np.float64]]:
    T = translate(x, y, z) * rotate(rx, ry, rz)
    return get_inverse_kinematics(robot, T)
