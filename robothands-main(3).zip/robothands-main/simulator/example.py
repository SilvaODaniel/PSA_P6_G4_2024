from response import Response


Response.model_validate_json('{"lol":1}')
