from queue import Empty, Full
import socket as s
from threading import Thread
from request import Request
from response import Response
from utils import ConsumerQueue, ProducerQueue, create_consumer_producer_pair


def block_and_listen(
    sock: s.socket,
    request_queue: ProducerQueue[Request],
    response_queue: ConsumerQueue[Response],
):
    sock.listen(1)
    print("Server daemon thread started")

    while True:
        client, _ = sock.accept()
        while True:
            try:
                data = client.recv(8192)
                if len(data) < 1:
                    break  # wait new connection
                response = None
                request = None
                try:
                    request = Request.model_validate_json(data)
                except Exception as e:
                    print(e)
                    print(f"Invalid JSON:\n\t'{data}'")

                if request is None:
                    response = Response.error("Bad request")
                else:
                    try:
                        request_queue.put(request, timeout=5)
                    except Full:
                        response = Response.error("Server took too long to poll")

                    if response is None:
                        try:
                            response = response_queue.get(timeout=5)
                        except Empty:
                            response = Response.error("Server took too long to respond")

                client.sendall(
                    response.model_dump_json(warnings="error").encode("utf-8")
                )
            except ConnectionAbortedError:
                print("Connection aborted by the client.")
                break


def start_server(port: int):
    sock = s.socket(s.AF_INET, s.SOCK_STREAM)
    sock.bind(("localhost", port))
    request_producer_queue, request_consumer_queue = create_consumer_producer_pair(
        Request, 1
    )
    response_producer_queue, response_consumer_queue = create_consumer_producer_pair(
        Response, 1
    )
    thread = Thread(
        target=block_and_listen,
        args=(sock, request_producer_queue, response_consumer_queue),
        daemon=True,
    )
    thread.start()
    return request_consumer_queue, response_producer_queue
