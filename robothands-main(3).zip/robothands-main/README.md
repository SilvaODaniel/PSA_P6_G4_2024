## Run Main Application

Start [Robot client](task\robot.py) and [Hand detection client](task\hands.py):

```bash
python main.py
```

## Debug Scripts Offline

If you want to run offline (for developing things that don't need the real robot) you can also [run the fake server](./start_fake_robot_server.py):

```bash
python start_fake_robot_server.py
```

If doing this, you'll also need to prevent the main script from using the real IP. To do this just add the `--localhost` flag:

```bash
python main.py --localhost
```

_DISCLAIMER: the simulation server is unstable and has the wrong coordinate system, so it's likely that otherwise reasonable code won't execute the expected movements in the simulation. It's mostly useful to test the API itself._

_NOTE: if using the localhost flag, the real robot won't be used, even if it is reachable._

## Collect Data from Robot

You can also collect real JSON data that the machine sends into a [log file](./logs/elite_responses.log), by running:

```bash
python record_responses.py
```
